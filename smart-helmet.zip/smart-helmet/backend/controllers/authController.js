// ============================================
// CONTRÔLEUR D'AUTHENTIFICATION
// Ticket BK-02 : Implémentation Login/Register avec JWT
// ============================================

// Importer le modèle User pour accéder à la base de données
const User = require('../models/User');

// Importer jsonwebtoken pour créer des tokens d'authentification
const jwt = require('jsonwebtoken');

// Charger les variables d'environnement
require('dotenv').config();

// ============================================
// FONCTION: Générer un token JWT
// ============================================
const generateToken = (userId, email, role) => {
    // Créer le payload (données à encoder dans le token)
    const payload = {
        userId,  // ID de l'utilisateur
        email,   // Email de l'utilisateur
        role     // Rôle (user, admin, etc.)
    };

    // Signer le token avec la clé secrète et définir la durée de validité
    return jwt.sign(
        payload,
        process.env.JWT_SECRET,
        { expiresIn: process.env.JWT_EXPIRE }
    );
};

// ============================================
// CONTRÔLEUR: Inscription (Register)
// ============================================
const register = async (req, res) => {
    try {
        // Extraire les données du corps de la requête
        const { name, email, password, helmet_id } = req.body;

        // ==========================================
        // VALIDATION DES DONNÉES
        // ==========================================

        // Vérifier que tous les champs requis sont présents
        if (!name || !email || !password) {
            return res.status(400).json({
                status: 'ERROR',
                message: 'Le nom, l\'email et le mot de passe sont requis'
            });
        }

        // Vérifier le format de l'email
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email)) {
            return res.status(400).json({
                status: 'ERROR',
                message: 'Format d\'email invalide'
            });
        }

        // Vérifier la longueur du mot de passe (minimum 6 caractères)
        if (password.length < 6) {
            return res.status(400).json({
                status: 'ERROR',
                message: 'Le mot de passe doit contenir au moins 6 caractères'
            });
        }

        // ==========================================
        // CRÉATION DE L'UTILISATEUR
        // ==========================================

        // Créer l'utilisateur dans la base de données
        const user = await User.create({
            name,
            email,
            password,
            helmet_id
        });

        // ==========================================
        // CRÉATION DU TOKEN JWT
        // ==========================================

        // Générer un token JWT pour l'utilisateur
        const token = generateToken(user.id, user.email, user.role);

        // ==========================================
        // RÉPONSE DE SUCCÈS
        // ==========================================

        res.status(201).json({
            status: 'SUCCESS',
            message: '✅ Compte créé avec succès',
            token,
            user: {
                id: user.id,
                name: user.name,
                email: user.email,
                helmet_id: user.helmet_id,
                role: user.role
            }
        });

    } catch (error) {
        console.error('❌ Erreur inscription:', error);

        // Gérer l'erreur d'email déjà utilisé
        if (error.message === 'Cet email est déjà utilisé') {
            return res.status(409).json({
                status: 'ERROR',
                message: '📧 Cet email est déjà utilisé'
            });
        }

        // Erreur serveur interne
        res.status(500).json({
            status: 'ERROR',
            message: '❌ Erreur lors de la création du compte'
        });
    }
};

// ============================================
// CONTRÔLEUR: Connexion (Login)
// ============================================
const login = async (req, res) => {
    try {
        // Extraire l'email et le mot de passe de la requête
        const { email, password } = req.body;

        // ==========================================
        // VALIDATION DES DONNÉES
        // ==========================================

        if (!email || !password) {
            return res.status(400).json({
                status: 'ERROR',
                message: '📧 L\'email et le mot de passe sont requis'
            });
        }

        // ==========================================
        // RECHERCHE DE L'UTILISATEUR
        // ==========================================

        // Chercher l'utilisateur par email
        const user = await User.findByEmail(email);

        // Si l'utilisateur n'existe pas
        if (!user) {
            return res.status(401).json({
                status: 'ERROR',
                message: '🔐 Email ou mot de passe incorrect'
            });
        }

        // ==========================================
        // VÉRIFICATION DU MOT DE PASSE
        // ==========================================

        // Comparer le mot de passe fourni avec le hash stocké
        const isPasswordValid = await User.comparePassword(password, user.password);

        // Si le mot de passe est incorrect
        if (!isPasswordValid) {
            return res.status(401).json({
                status: 'ERROR',
                message: '🔐 Email ou mot de passe incorrect'
            });
        }

        // ==========================================
        // CRÉATION DU TOKEN JWT
        // ==========================================

        const token = generateToken(user.id, user.email, user.role);

        // ==========================================
        // RÉPONSE DE SUCCÈS
        // ==========================================

        res.json({
            status: 'SUCCESS',
            message: '✅ Connexion réussie',
            token,
            user: {
                id: user.id,
                name: user.name,
                email: user.email,
                helmet_id: user.helmet_id,
                role: user.role
            }
        });

    } catch (error) {
        console.error('❌ Erreur connexion:', error);

        res.status(500).json({
            status: 'ERROR',
            message: '❌ Erreur lors de la connexion'
        });
    }
};

// ============================================
// CONTRÔLEUR: Obtenir le profil utilisateur
// ============================================
const getProfile = async (req, res) => {
    try {
        // L'ID utilisateur est dans req.user (ajouté par le middleware auth)
        const userId = req.user.userId;

        // Chercher l'utilisateur par ID
        const user = await User.findById(userId);

        if (!user) {
            return res.status(404).json({
                status: 'ERROR',
                message: 'Utilisateur non trouvé'
            });
        }

        // Renvoyer les informations de l'utilisateur
        res.json({
            status: 'SUCCESS',
            user: {
                id: user.id,
                name: user.name,
                email: user.email,
                helmet_id: user.helmet_id,
                role: user.role,
                created_at: user.created_at
            }
        });

    } catch (error) {
        console.error('❌ Erreur profil:', error);

        res.status(500).json({
            status: 'ERROR',
            message: '❌ Erreur lors de la récupération du profil'
        });
    }
};

// Exporter les fonctions du contrôleur
module.exports = {
    register,
    login,
    getProfile
};