// ============================================
// MODULE DE CONNEXION À POSTGRESQL
// Ticket BK-01 : Modélisation Base de Données
// ============================================

// Importer le module 'pg' pour se connecter à PostgreSQL
const { Pool } = require('pg');

// Charger les variables d'environnement depuis .env
require('dotenv').config();

// Créer un pool de connexions PostgreSQL
// Le pool réutilise les connexions pour améliorer les performances
const pool = new Pool({
    // Adresse du serveur PostgreSQL (localhost = même machine)
    host: process.env.DB_HOST,

    // Port PostgreSQL (par défaut 5432)
    port: parseInt(process.env.DB_PORT),

    // Nom d'utilisateur PostgreSQL
    user: process.env.DB_USER,

    // Mot de passe PostgreSQL
    password: process.env.DB_PASSWORD,

    // Nom de la base de données à utiliser
    database: process.env.DB_NAME,

    // Nombre maximum de connexions simultanées
    max: 20,

    // Fermer les connexions inactives après 30 secondes
    idleTimeoutMillis: 30000,

    // Timeout de connexion (2 secondes maximum)
    connectionTimeoutMillis: 2000,
});

// Gérer les erreurs sur les connexions inactives
pool.on('error', (err) => {
    console.error('❌ Erreur critique sur une connexion PostgreSQL:', err);
    process.exit(-1); // Arrêter l'application en cas d'erreur critique
});

// Tester la connexion au démarrage
(async () => {
    try {
        // Exécuter une requête simple pour tester la connexion
        await pool.query('SELECT NOW()');

        // Afficher un message de succès avec les détails de connexion
        console.log('✅ Connexion PostgreSQL réussie !');
        console.log(`📊 Base de données: ${process.env.DB_NAME}`);
        console.log(`📍 Hôte: ${process.env.DB_HOST}:${process.env.DB_PORT}\n`);
    } catch (error) {
        // Afficher l'erreur et des conseils de dépannage
        console.error('❌ ÉCHEC de la connexion à PostgreSQL:');
        console.error(`   Message: ${error.message}\n`);
        console.error('💡 Conseils de dépannage:');
        console.error('   1. Vérifie que PostgreSQL est démarré');
        console.error('   2. Vérifie les identifiants dans .env');
        console.error('   3. Vérifie que la base "smart_helmet_db" existe dans pgAdmin\n');

        // Arrêter l'application si la connexion échoue
        process.exit(1);
    }
})();

// Exporter le pool pour l'utiliser dans toute l'application
module.exports = pool;