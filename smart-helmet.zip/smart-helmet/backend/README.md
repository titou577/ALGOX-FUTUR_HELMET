# 🛡️ Smart Helmet - Backend API (Sprint 1)

## 🎫 Tickets Implémentés
- **BK-01** : Modélisation PostgreSQL 16 (Tables: users, health_logs, accidents, trips)
- **BK-02** : API Core & Auth JWT (Node.js 20/Express, bcrypt, JWT)

## 🚀 Technologies
- Node.js v20
- Express v4.18.2
- PostgreSQL v16
- JWT pour l'authentification
- Bcrypt pour le hashage des mots de passe

## 📋 Prérequis
- Node.js installé
- PostgreSQL installé et démarré
- Mot de passe PostgreSQL: `1234567890`

## 🛠️ Installation

### 1. Installer les dépendances
```bash
cd smart-helmet/backend
npm install