// ============================================
// MIDDLEWARE D'AUTHENTIFICATION JWT
// Ticket BK-02 : Sécurisation des routes avec JWT
// ============================================

// Importer jsonwebtoken pour vérifier les tokens
const jwt = require('jsonwebtoken');

// Charger les variables d'environnement
require('dotenv').config();

// ============================================
// MIDDLEWARE: Vérifier le token JWT
// ============================================
const authenticateToken = (req, res, next) => {
    try {
        // ==========================================
        // EXTRAIRE LE TOKEN DE L'EN-TÊTE AUTHORIZATION
        // ==========================================

        // Récupérer l'en-tête Authorization (format: "Bearer <token>")
        const authHeader = req.headers['authorization'];

        // Extraire uniquement le token (après "Bearer ")
        // Exemple: "Bearer eyJhbGci..." → "eyJhbGci..."
        const token = authHeader && authHeader.split(' ')[1];

        // Si aucun token n'est fourni
        if (!token) {
            return res.status(401).json({
                status: 'ERROR',
                message: '🔐 Token d\'authentification manquant'
            });
        }

        // ==========================================
        // VÉRIFIER ET DÉCODER LE TOKEN
        // ==========================================

        // Vérifier le token avec la clé secrète
        jwt.verify(token, process.env.JWT_SECRET, (err, user) => {
            // Si le token est invalide
            if (err) {
                // Vérifier si le token est expiré
                if (err.name === 'TokenExpiredError') {
                    return res.status(401).json({
                        status: 'ERROR',
                        message: '⏰ Token expiré, veuillez vous reconnecter'
                    });
                }

                // Token invalide pour une autre raison
                return res.status(403).json({
                    status: 'ERROR',
                    message: '🔐 Token d\'authentification invalide'
                });
            }

            // ==========================================
            // STOCKER LES DONNÉES UTILISATEUR DANS LA REQUÊTE
            // ==========================================

            // Ajouter les informations de l'utilisateur à req.user
            // Permet aux routes suivantes d'accéder à req.user
            req.user = user;

            // Passer au middleware/route suivant
            next();
        });

    } catch (error) {
        console.error('❌ Erreur middleware auth:', error);

        res.status(500).json({
            status: 'ERROR',
            message: '❌ Erreur lors de la vérification du token'
        });
    }
};

// Exporter le middleware
module.exports = {
    authenticateToken
};