// ============================================
// SERVEUR PRINCIPAL - SMART HELMET SPRINT 1
// Tickets: BK-01 (Base de Données) & BK-02 (Auth JWT)
// ============================================

// Importer Express (framework web pour Node.js)
const express = require('express');

// Importer CORS (permet aux requêtes frontend de communiquer avec le backend)
const cors = require('cors');

// Charger les variables d'environnement
require('dotenv').config();

// Importer le module de connexion à la base de données
const pool = require('./database');

// Créer une instance de l'application Express
const app = express();

// Définir le port du serveur (5000 par défaut)
const PORT = process.env.PORT || 5000;

// ============================================
// MIDDLEWARES
// ============================================

// Activer CORS pour autoriser les requêtes depuis n'importe quelle origine
// (À restreindre en production avec origin: 'http://localhost:3000')
app.use(cors());

// Parser le corps des requêtes en JSON
app.use(express.json());

// Parser les données de formulaire HTML
app.use(express.urlencoded({ extended: true }));

// ============================================
// ROUTES DE SANTÉ
// ============================================

// Route: Vérifier l'état du serveur
app.get('/health', (req, res) => {
    res.json({
        status: 'OK',
        message: '✅ Smart Helmet API - Sprint 1 opérationnel',
        timestamp: new Date().toISOString(),
        environment: process.env.NODE_ENV
    });
});

// Route: Tester la connexion à la base de données
app.get('/test-db', async (req, res) => {
    try {
        // Exécuter une requête simple pour tester la connexion
        const result = await pool.query('SELECT NOW() as current_time');

        // Répondre avec succès et l'heure de la base de données
        res.json({
            status: 'OK',
            message: '✅ Connexion PostgreSQL réussie',
            database: process.env.DB_NAME,
            time: result.rows[0].current_time
        });
    } catch (error) {
        // Répondre avec une erreur en cas d'échec
        res.status(500).json({
            status: 'ERROR',
            message: '❌ Erreur de connexion à la base de données',
            error: error.message
        });
    }
});

// ============================================
// ROUTES D'AUTHENTIFICATION (Ticket BK-02)
// ============================================

// Importer et utiliser les routes d'authentification
app.use('/api/auth', require('./routes/auth'));

// ============================================
// GESTION DES ERREURS
// ============================================

// Middleware pour les routes non trouvées (404)
app.use((req, res) => {
    res.status(404).json({
        status: 'ERROR',
        message: `atedRoute non trouvée: ${req.method} ${req.originalUrl}`
    });
});

// Middleware pour les erreurs serveur (500)
app.use((err, req, res, next) => {
    console.error('❌ Erreur serveur:', err.stack);

    res.status(500).json({
        status: 'ERROR',
        message: 'Erreur serveur interne',
        ...(process.env.NODE_ENV === 'development' && { error: err.message })
    });
});

// ============================================
// DÉMARRER LE SERVEUR
// ============================================

app.listen(PORT, () => {
    console.log('='.repeat(50));
    console.log('🚀 SMART HELMET - SPRINT 1');
    console.log('='.repeat(50));
    console.log(`✅ Serveur démarré sur http://localhost:${PORT}`);
    console.log(`🔐 JWT expire: ${process.env.JWT_EXPIRE}`);
    console.log('='.repeat(50));
    console.log('\n📍 Endpoints disponibles:');
    console.log(`   GET  /health          → Santé du serveur`);
    console.log(`   GET  /test-db         → Test connexion DB`);
    console.log(`   POST /api/auth/register → Créer un compte`);
    console.log(`   POST /api/auth/login    → Se connecter`);
    console.log(`   GET  /api/auth/profile  → Profil utilisateur (avec token)\n`);
});