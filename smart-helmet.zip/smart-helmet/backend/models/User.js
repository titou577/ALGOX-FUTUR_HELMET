// ============================================
// MODÈLE UTILISATEUR - GESTION TABLE USERS
// Ticket BK-01 : Schéma relationnel PostgreSQL
// ============================================

// Importer le module de connexion à la base de données
const pool = require('../database');

// Importer bcrypt pour hasher les mots de passe (sécurité)
const bcrypt = require('bcrypt');

// Classe User avec méthodes pour interagir avec la table 'users'
class User {
    // ==========================================
    // CRÉER UN NOUVEL UTILISATEUR
    // ==========================================
    static async create(userData) {
        const { name, email, password, helmet_id } = userData;

        try {
            // Hasher le mot de passe avec bcrypt (10 tours de hashage)
            // Transforme "123456" en chaîne cryptée comme "$2b$10$..."
            const hashedPassword = await bcrypt.hash(password, 10);

            // Insérer l'utilisateur dans la base de données
            // $1, $2, $3... sont des paramètres pour éviter les injections SQL
            const result = await pool.query(
                `INSERT INTO users (name, email, password, helmet_id, role) 
         VALUES ($1, $2, $3, $4, $5) 
         RETURNING id, name, email, helmet_id, role, created_at`,
                [name, email, hashedPassword, helmet_id, 'user'] // Rôle par défaut: 'user'
            );

            // Retourner les données de l'utilisateur créé (sans le mot de passe)
            return result.rows[0];
        } catch (error) {
            // Si l'email existe déjà (erreur UNIQUE violation dans PostgreSQL)
            if (error.code === '23505') {
                throw new Error('Cet email est déjà utilisé');
            }
            throw error;
        }
    }

    // ==========================================
    // TROUVER UN UTILISATEUR PAR EMAIL
    // ==========================================
    static async findByEmail(email) {
        try {
            // Rechercher l'utilisateur par email dans la base de données
            const result = await pool.query(
                'SELECT * FROM users WHERE email = $1',
                [email]
            );

            // Retourner l'utilisateur ou null si non trouvé
            return result.rows[0] || null;
        } catch (error) {
            throw error;
        }
    }

    // ==========================================
    // TROUVER UN UTILISATEUR PAR ID
    // ==========================================
    static async findById(id) {
        try {
            // Sélectionner l'utilisateur par ID (sans le mot de passe)
            const result = await pool.query(
                'SELECT id, name, email, helmet_id, role, created_at FROM users WHERE id = $1',
                [id]
            );

            return result.rows[0] || null;
        } catch (error) {
            throw error;
        }
    }

    // ==========================================
    // COMPARER UN MOT DE PASSE AVEC LE HASH STOCKÉ
    // ==========================================
    static async comparePassword(password, hashedPassword) {
        try {
            // Comparer le mot de passe en clair avec le hash stocké
            // Retourne true si les mots de passe correspondent
            return await bcrypt.compare(password, hashedPassword);
        } catch (error) {
            throw error;
        }
    }
}

// Exporter la classe User pour l'utiliser dans les contrôleurs
module.exports = User;