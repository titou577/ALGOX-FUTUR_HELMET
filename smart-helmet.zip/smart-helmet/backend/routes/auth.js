// ============================================
// ROUTES D'AUTHENTIFICATION
// Ticket BK-02 : Endpoints Login/Register
// ============================================

// Importer Express pour créer les routes
const express = require('express');

// Créer un routeur Express
const router = express.Router();

// Importer le contrôleur d'authentification
const {
    register,
    login,
    getProfile
} = require('../controllers/authController');

// Importer le middleware d'authentification
const { authenticateToken } = require('../middleware/auth');

// ============================================
// ROUTE: Inscription (Register)
// Méthode: POST
// Endpoint: /api/auth/register
// Accès: Public (pas d'authentification requise)
// ============================================
router.post('/register', register);

// ============================================
// ROUTE: Connexion (Login)
// Méthode: POST
// Endpoint: /api/auth/login
// Accès: Public (pas d'authentification requise)
// ============================================
router.post('/login', login);

// ============================================
// ROUTE: Profil utilisateur
// Méthode: GET
// Endpoint: /api/auth/profile
// Accès: Privé (authentification requise via JWT)
// Le middleware authenticateToken vérifie le token avant getProfile
// ============================================
router.get('/profile', authenticateToken, getProfile);

// Exporter le routeur pour l'utiliser dans server.js
module.exports = router;