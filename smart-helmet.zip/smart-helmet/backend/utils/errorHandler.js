// ============================================
// GESTIONNAIRE D'ERREURS GLOBAL
// ============================================

// ============================================
// CLASSE PERSONNALISÉE POUR LES ERREURS
// ============================================
class AppError extends Error {
    constructor(message, statusCode) {
        // Appeler le constructeur parent (Error)
        super(message);

        // Définir le code de statut HTTP
        this.statusCode = statusCode || 500;

        // Définir le statut (error ou fail)
        this.status = `${statusCode}`.startsWith('4') ? 'fail' : 'error';

        // Ne pas inclure la stack trace dans la réponse en production
        this.isOperational = true;

        // Capturer la stack trace
        Error.captureStackTrace(this, this.constructor);
    }
}

// ============================================
// MIDDLEWARE DE GESTION D'ERREURS
// ============================================
const errorHandler = (err, req, res, next) => {
    // Définir le code de statut (500 par défaut)
    const statusCode = err.statusCode || 500;

    // Définir le message d'erreur (message de l'erreur ou message par défaut)
    const message = err.message || 'Erreur serveur interne';

    // ==========================================
    // LOG DE L'ERREUR (SERVEUR)
    // ==========================================

    // Afficher l'erreur dans la console (toujours, même en production)
    console.error('❌ Erreur:', err);

    // ==========================================
    // ENVOYER LA RÉPONSE AU CLIENT
    // ==========================================

    res.status(statusCode).json({
        status: 'ERROR',
        message,
        // En mode développement, inclure la stack trace pour le débogage
        ...(process.env.NODE_ENV === 'development' && { stack: err.stack })
    });
};

// ============================================
// EXPORT
// ============================================

module.exports = {
    AppError,
    errorHandler
};